#ifndef ARRAYS_H
#define ARRAYS_H
void convert_char_arr_to_int_arr(char **charArr, int *intArr, int size, int startIndex);
#endif