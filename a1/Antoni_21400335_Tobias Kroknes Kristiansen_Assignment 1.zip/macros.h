#ifndef MACROS_H
#define MACROS_H

#define FALSE 0
#define TRUE !FALSE

#define MAP_MIN 5
#define MAP_MAX 100

#endif